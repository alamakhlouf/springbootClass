package tn.esprit.spring.springboot1alinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot1AlinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
