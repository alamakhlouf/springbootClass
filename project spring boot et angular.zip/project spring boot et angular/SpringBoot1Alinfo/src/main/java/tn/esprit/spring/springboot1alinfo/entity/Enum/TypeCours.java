package tn.esprit.spring.springboot1alinfo.entity.Enum;

public enum TypeCours {
    COLLECTIF_ENFANT , COLLECTIF_ADULTE , PARTICULIER
}
