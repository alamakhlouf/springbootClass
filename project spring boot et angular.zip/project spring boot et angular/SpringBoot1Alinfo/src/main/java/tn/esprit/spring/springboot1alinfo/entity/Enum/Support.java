package tn.esprit.spring.springboot1alinfo.entity.Enum;

public enum Support {
    SKY , SNOWBOARD
}
