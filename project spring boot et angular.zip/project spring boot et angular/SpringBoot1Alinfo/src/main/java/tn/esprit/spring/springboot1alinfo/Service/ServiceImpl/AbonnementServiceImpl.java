package tn.esprit.spring.springboot1alinfo.Service.ServiceImpl;

public class AbonnementServiceImpl {
}
