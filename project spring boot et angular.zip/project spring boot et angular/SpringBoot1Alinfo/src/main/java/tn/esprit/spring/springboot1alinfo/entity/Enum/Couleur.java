package tn.esprit.spring.springboot1alinfo.entity.Enum;

public enum Couleur {
    VERT , BLEU ,ROUGE ,NOIR

}
