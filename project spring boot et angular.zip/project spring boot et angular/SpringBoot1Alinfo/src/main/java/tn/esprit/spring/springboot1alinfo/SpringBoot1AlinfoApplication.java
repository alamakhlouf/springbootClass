package tn.esprit.spring.springboot1alinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot1AlinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot1AlinfoApplication.class, args);
	}

}
