package tn.esprit.spring.springboot1alinfo.entity.Enum;

public enum TypeAbonnement {
ANNUEL , SEMESTRIEL , MENSUEL
}
