package tn.esprit.spring.springboot1alinfo.Controller;

public class AbonnementController {
}
